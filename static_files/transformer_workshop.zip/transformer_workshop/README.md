# Transformers from Scratch — hands-on session

A ~2 hour hands-on notebook that starts from a bigram lookup table, builds a decoder-only Transformer (GPT)
in PyTorch one component at a time, trains it on Indian/IIT Delhi text, and then proves the same code
reproduces real GPT-2.

## Contents

```
transformers_from_scratch.ipynb   the session (95 cells)
data/iitd_india.txt               1.3MB India / IIT Delhi corpus (Wikipedia, CC BY-SA 4.0)
build_corpus.py                   rebuilds or retargets that corpus
images/                           illustrations used in the markdown cells
```

## Requirements

```bash
pip install torch numpy plotly nbformat tiktoken transformers
```

`nbformat` is easy to forget — plotly needs it to render inside a notebook and errors without it. Cell 1 of
the notebook checks all of these and prints the exact `pip install` line if anything is missing.

Sections 1–15 only need `torch numpy plotly nbformat`. Sections 16–17 add `tiktoken` and `transformers`.

## Before the session

**Pre-download the GPT-2 weights (~500MB)** so you aren't waiting on venue wifi:

```bash
python -c "from transformers import AutoModelForCausalLM, AutoTokenizer; \
AutoTokenizer.from_pretrained('gpt2'); AutoModelForCausalLM.from_pretrained('gpt2')"
```

Everything else — images and training data — is bundled locally, so sections 1–15 run fully offline.

## Running it

```bash
jupyter lab transformers_from_scratch.ipynb     # or open it in VS Code / Cursor
```

Run cells top to bottom; later sections reuse classes defined earlier. A GPU is used if present but not
required — on CPU, cut `max_iters` to ~500.

## Timings (measured, NVIDIA H200)

| Section | Wall clock |
|---|---|
| Everything before training | ~5s |
| Bigram baseline (1500 steps) | ~11s |
| Training the char model (3000 steps) | ~63s |
| Training the word model (2000 steps, §16.1) | ~37s |
| GPT-2 load + inference | ~10s (after weights are cached) |
| Full notebook, top to bottom | ~140s |

Compute is never the bottleneck — the two hours are for explanation and the exercises.

## Structure

| Section | Component |
|---|---|
| 1 | The big picture — encoder-decoder vs decoder-only |
| 2–3 | Character tokenizer, batching, token embeddings |
| 4 | **Bigram baseline** — the simplest LM there is, the reusable training loop, and the number to beat |
| 5 | Positional encoding (with a permutation test showing why it's needed) |
| 6 | Scaled dot-product attention, and why the √d_k |
| 7 | Causal masking |
| 8 | Multi-head attention (verified against `F.scaled_dot_product_attention`) |
| 9 | Feed-forward network |
| 10 | Residual connections + LayerNorm (gradient-flow demo) |
| 11 | The Transformer block |
| 12 | **MiniGPT** — the full model, 0.8M params |
| 13 | Training loop |
| 14 | Generation: temperature and top-k |
| 15 | Attention maps from the trained model |
| 16.1 | **Word-level tokenizer** — trained head-to-head against char-level; `<UNK>`, overfitting, and why cross-tokenizer loss comparison is invalid |
| 16.2 | **BPE** — why it resolves both failure modes; context compression and vocabulary cost |
| 17 | **Real GPT-2 (124M)** — module-by-module mapping onto our classes, and a numerical proof |
| 18 | Recap, what we skipped, take-home exercises |

Section 17's centrepiece: we pull GPT-2's actual `c_attn` weights out of HuggingFace, run them through the
`scaled_dot_product_attention` function written in section 6, and match HuggingFace's own output to ~3e-07.
Its localised demo: *"The capital of India is New Delhi, and the capital of Japan is"* → **" Tokyo"**.

§16.1 is the one to protect if you're running long. Two things land there: the *better-looking* samples came
from the worse model, and the obvious way to compare two tokenizers is invalid. Measured on this corpus, the
word model's validation loss bottoms out at step 750 and then climbs while the character model's keeps
falling; 11.6% of the validation text is `<UNK>` (including, aptly, the word *transformer*); and dividing its
loss by 5.05 characters/token would claim it is 42% better, which it is not.

Seven **🔧 Your turn** exercises are embedded in the flow. Drop them if you're short on time.

## Interactive plots

All 10 figures are plotly: hover for values, drag to zoom, double-click to reset, click the legend to toggle
traces. Two have dropdown menus:

- **MiniGPT attention explorer** — 16 buttons, one per (layer, head)
- **GPT-2 attention explorer** — 12 buttons, one per layer, each showing all 12 heads at once

## Model

`n_layer=4, n_head=4, n_embd=128, block_size=128` → ~0.8M parameters, 80-character vocabulary.

| model | val loss | perplexity |
|---|---|---|
| uniform guessing | 4.38 | 80.0 |
| bigram (6,400 params) | 2.67 | 14.4 |
| MiniGPT (818k params) | 1.81 | 6.1 |

That 0.86 nats/character gap between the bigram and MiniGPT is what attention buys, and the notebook plots
the baseline directly on the training curve.

## Corpus

`data/iitd_india.txt` is ~1.3MB of English Wikipedia prose on IIT Delhi, the IIT system, JEE, Delhi, India,
ISRO and Chandrayaan, the Delhi Metro, and Indian scientists (Raman, Bhabha, Ramanujan, Kalam, Sarabhai,
Aryabhata). Accents and non-Latin scripts are folded to ASCII to keep the character vocabulary at 80.
Wikipedia text is CC BY-SA 4.0. Run `python build_corpus.py` to rebuild it or edit `TITLES` to retarget it.

## Image credits

Illustrations are from Jay Alammar's [The Illustrated Transformer](https://jalammar.github.io/illustrated-transformer/)
and [The Illustrated GPT-2](https://jalammar.github.io/illustrated-gpt2/), plus the architecture figure from
Vaswani et al. 2017 ([arXiv:1706.03762](https://arxiv.org/abs/1706.03762)) via Wikimedia Commons. Each is
attributed inline in the notebook. Check the original licenses before reusing them outside a teaching context.
