"""Rebuild data/iitd_india.txt from English Wikipedia.

The workshop corpus is ~1.3MB of Wikipedia prose about IIT Delhi, the IIT system, Delhi,
India, ISRO and several Indian scientists. Wikipedia text is CC BY-SA 4.0.

Add or remove titles in TITLES below to retarget the corpus, then:

    python build_corpus.py
"""
import json, re, unicodedata, time, urllib.parse, urllib.request

UA = "TransformerWorkshop/1.0 (educational notebook)"
OUT = "data/iitd_india.txt"

TITLES = [
    "Indian Institute of Technology Delhi", "Indian Institutes of Technology",
    "Indian Institute of Technology Bombay", "Indian Institute of Technology Madras",
    "Indian Institute of Technology Kanpur", "Indian Institute of Technology Kharagpur",
    "Indian Institute of Technology Roorkee", "Indian Institute of Technology Guwahati",
    "Joint Entrance Examination", "Joint Entrance Examination – Advanced",
    "Delhi", "New Delhi", "Hauz Khas", "Qutub Minar", "India Gate",
    "India", "Indian Institute of Science", "Education in India",
    "All India Institute of Medical Sciences, New Delhi",
    "Indian Space Research Organisation", "Chandrayaan-3", "Indian Railways",
    "Culture of India", "Indian cuisine", "History of India", "Economy of India",
    "Delhi Metro", "Jawaharlal Nehru University", "University of Delhi",
    "Council of Scientific and Industrial Research", "C. V. Raman", "Homi J. Bhabha",
    "A. P. J. Abdul Kalam", "Srinivasa Ramanujan", "Vikram Sarabhai", "Satish Dhawan",
    "Aryabhata",
]

DROP = re.compile(r"^==+\s*(References|External links|See also|Further reading|Notes|"
                  r"Bibliography|Citations|Sources|Footnotes|Gallery)\s*==+\s*$", re.I)
JUNK = str.maketrans("", "", "#*<>[]^_|~{}\\@+")


def fetch(title):
    q = urllib.parse.urlencode({"action": "query", "prop": "extracts", "explaintext": "1",
                                "format": "json", "redirects": "1", "titles": title})
    req = urllib.request.Request("https://en.wikipedia.org/w/api.php?" + q,
                                 headers={"User-Agent": UA})
    page = list(json.load(urllib.request.urlopen(req, timeout=30))["query"]["pages"].values())[0]
    return page.get("title", ""), page.get("extract", "")


def ascii_fold(t):
    t = unicodedata.normalize("NFKD", t)
    for a, b in [("‘", "'"), ("’", "'"), ("“", '"'), ("”", '"'),
                 ("–", "-"), ("—", "-"), ("−", "-"), (" ", " ")]:
        t = t.replace(a, b)
    return t.encode("ascii", "ignore").decode("ascii")


def clean(text):
    text, out, skip = ascii_fold(text), [], False
    for line in text.split("\n"):
        if re.match(r"^==+.*==+\s*$", line):
            skip = bool(DROP.match(line))
        if not skip:
            out.append(line)
    text = "\n".join(out).translate(JUNK)
    text = re.sub(r"\(\s*[^A-Za-z0-9()]*\s*\)", "", text)   # (Hindi: ) left by dropped scripts
    text = re.sub(r"\([^)]{0,40}:\s*\)", "", text)
    text = re.sub(r"\(\s*;\s*", "(", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r" ([,.;:!?])", r"\1", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


if __name__ == "__main__":
    parts = []
    for t in TITLES:
        try:
            title, extract = fetch(t)
            body = clean(extract)
            if len(body) > 500:
                parts.append(f"= {ascii_fold(title).translate(JUNK)} =\n\n{body}")
                print(f"{len(body):>8,}  {title}")
        except Exception as e:
            print(f"{'FAILED':>8}  {t}  ({type(e).__name__})")
        time.sleep(0.15)

    corpus = "\n\n\n".join(parts) + "\n"
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(corpus)
    print(f"\nwrote {OUT}: {len(corpus):,} characters, vocab {len(set(corpus))}")
